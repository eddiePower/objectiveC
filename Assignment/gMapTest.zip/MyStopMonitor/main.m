//
//  main.m
//  MyStopMonitor
//
//  Created by Eddie Power on 29/04/2014.
//  Copyright (c) 2014 Eddie Power. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MyStopMonitorAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([MyStopMonitorAppDelegate class]));
    }
}
