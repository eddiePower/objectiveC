//
//  MyStopMonitorAppDelegate.h
//  MyStopMonitor
//
//  Created by Eddie Power on 29/04/2014.
//  Copyright (c) 2014 Eddie Power. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <GoogleMaps/GoogleMaps.h>
#import "MyStopMonitorViewController.h"

@interface MyStopMonitorAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
