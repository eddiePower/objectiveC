//
//  MyStopMonitorViewController.m
//  MyStopMonitor
//
//  Created by Eddie Power on 29/04/2014.
//  Copyright (c) 2014 Eddie Power. All rights reserved.
//

#import "MyStopMonitorViewController.h"


@interface MyStopMonitorViewController ()

@property (strong, nonatomic) GMSMapView *mapView;

@property (weak, nonatomic) IBOutlet UILabel *zoomLabel;

@end

@implementation MyStopMonitorViewController


- (void)viewDidLoad
{
    [super viewDidLoad];
   
    //Create a GMSCameraPosition that tells the map to display the co-ord's
    // -38.1397617, 145.1426698 at a zoom level of 6.
    GMSCameraPosition *camera = [GMSCameraPosition cameraWithLatitude: -38.1397617
                                                            longitude:145.1426698
                                                                 zoom: 16
                                                              bearing: 330
                                                         viewingAngle: 45];
    
    self.mapView = [GMSMapView mapWithFrame: self.view.bounds camera: camera];

    
    NSLog(@"\nCamera Details\nThe bearing is: %f\nThe viewing Angle is: %f\nMap Type is: %u \n",
    camera.bearing, camera.viewingAngle, self.mapView.mapType);
    
    //Set the map type either None, Satalite, Hybrid, Normal, or terrain
    self.mapView.mapType = kGMSTypeNormal;

    //Creates a marker in the center of the map.
    GMSMarker *marker = [[GMSMarker alloc] init];
    marker.position = CLLocationCoordinate2DMake(-38.1397617, 145.1426698);
    marker.title = @"Power Home!";
    marker.snippet = @"Frankston";
    marker.map = self.mapView;
    
    //Set the User Location on the map display or the famus blue dot!
    self.mapView.myLocationEnabled = YES;
    
    //Add the compas button in top right corner to re rotate the map to north @ top.
    self.mapView.settings.compassButton = YES;
    
    //Add the find my Location button in bottom right corner.
    self.mapView.settings.myLocationButton = YES;
    
    //Add the mapView to the mainView or window as a subView.
    [self.view addSubview: self.mapView];
}


//Hide the status bar at top of iphone screen for iOS 7+
- (BOOL)prefersStatusBarHidden
{
    return YES;
}

- (void)viewWillLayoutSubviews
{
    [super viewWillLayoutSubviews];
    
    self.mapView.padding = UIEdgeInsetsMake(self.topLayoutGuide.length +
                                            5, 0, self.bottomLayoutGuide.length + 5, 0);
}

@end
