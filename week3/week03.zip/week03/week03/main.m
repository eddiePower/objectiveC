//
//  main.m
//  week03
//
//  Created by Eddie Power on 19/03/2014.
//  Copyright (c) 2014 Eddie Power. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "EMPAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([EMPAppDelegate class]));
    }
}
