//
//  EMPViewController.h
//  week03
//
//  Created by Eddie Power on 19/03/2014.
//  Copyright (c) 2014 Eddie Power. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EMPViewController : UIViewController

@end
