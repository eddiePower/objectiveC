//
//  MyConstants.m
//  MyStopMonitorV1.1
//
//  Created by Eddie Power on 12/06/2014.
//  Copyright (c) 2014 Eddie Power. All rights reserved.
//

#import "MyConstants.h"

@implementation MyConstants

NSString* kCellTitleKey = @"CellTitle";

@end
