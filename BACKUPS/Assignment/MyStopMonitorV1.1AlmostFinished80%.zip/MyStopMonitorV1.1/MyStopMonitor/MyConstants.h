//
//  MyConstants.h
//  MyStopMonitorV1.1
//
//  Created by Eddie Power on 12/06/2014.
//  Copyright (c) 2014 Eddie Power. All rights reserved.
//

#import <Foundation/Foundation.h>

static float kalertRadius = 350.0f;
extern  NSString* kCellTitleKey;




@interface MyConstants : NSObject
@end
