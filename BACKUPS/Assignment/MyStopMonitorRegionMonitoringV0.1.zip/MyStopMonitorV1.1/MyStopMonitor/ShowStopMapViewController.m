//////////////////////////////////////////////////////////////////////////
//  ShowStopMapViewController.h                                        //
//  MyStopMonitor                                                     //
//                                                                   //
//  PROJECT DESCRIPTION AREA OF EACH TASK ACHIEVED BY THIS FILE     //
//                                                                 //
//  Created by Eddie Power on 1/05/2014.                          //
//  Copyright (c) 2014 Eddie Power.                              //
//  All rights reserved.                                        //
/////////////////////////////////////////////////////////////////


#import "ShowStopMapViewController.h"
#import "StopAnnotation.h"

@implementation ShowStopMapViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    //MapView Configuration.
    self.mapView.showsBuildings = YES;
    self.mapView.showsUserLocation = YES;
    
    self.stationNameLabel.text = self.mapStation.stationName;
    self.stationTypeLabel.text = [NSString stringWithFormat:@"Transport Type: %@", self.mapStation.stationStopType];
   
    //Set the mapView Delegate to return to itself for annotations.
    self.mapView.delegate = self;
   
    //Set the region/area for the mapView location to show.
    MKCoordinateRegion mapCoordRegion;
    
    //center location for mapView
    CLLocationCoordinate2D center;
    center.latitude = [self.mapStation.stationLatitude doubleValue];
    center.longitude = [self.mapStation.stationLongitude doubleValue];
    
    //Span @ % of degree = 100th of degree
    MKCoordinateSpan span;
    span.latitudeDelta = 0.001f;
    span.longitudeDelta = 0.001f;
    
    //Set center and span for the mapView region
    mapCoordRegion.center = center;
    mapCoordRegion.span = span;
    
    //Set the Region to the mapView.
    [self.mapView setRegion: mapCoordRegion animated: YES];

    //init annotation for Stop title, coord of stop and subtitle used for map display only not region monitoring.
    StopAnnotation *item = [[StopAnnotation alloc] initWithTitle:self.mapStation.stationName aCoord:center andSubtitle:self.mapStation.stationStopType];

    //Add annotation array to the map
    [self.mapView addAnnotation: item];
   
    //overridden method below, adds custom pin and callout.
    [self.mapView viewForAnnotation: item];
    
    //FUTURE ADD TO MARKER THE MYKI OUTLET STATUS AND PARKING STATUS OF STATIONS.
    //Maybe in the call outs or annotations method below.
}

-(MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>)annotation
{
    // in case it's the user location, we already have an annotation, so just return nil
    if ([annotation isKindOfClass:[MKUserLocation class]])
    {
        return nil;
    }

    // handle my custom annotation may add others for bus/train/tram or other use.
    // for station or stop annotation
    if ([annotation isKindOfClass:[StopAnnotation class]])
    {
        
        static NSString *StopAnnotationIdentifier = @"StopAnnotation";
        
        MKPinAnnotationView *pinView =
        (MKPinAnnotationView *)[self.mapView dequeueReusableAnnotationViewWithIdentifier: StopAnnotationIdentifier];
        if (pinView == nil)
        {
            //if an existing pin view was not available, create one
            MKPinAnnotationView *customPinView =
            [[MKPinAnnotationView alloc] initWithAnnotation: annotation reuseIdentifier: StopAnnotationIdentifier];
            
            //Customize the pin view.
            customPinView.pinColor = MKPinAnnotationColorPurple;
            customPinView.animatesDrop = YES;
            customPinView.canShowCallout = YES;
            
            //Add a custom icon for the station/stop call out box
            UIImageView *stopIconView = [[UIImageView alloc] initWithImage:[UIImage imageNamed: @"StopIcon"]];
            customPinView.rightCalloutAccessoryView = stopIconView;
            
            // Create a button for the left callout accessory view of each annotation to remove the annotation and region being monitored.
			UIButton *removeRegionButton = [UIButton buttonWithType:UIButtonTypeCustom];
			[removeRegionButton setFrame:CGRectMake(0., 0., 25., 25.)];
			[removeRegionButton setImage:[UIImage imageNamed:@"RemoveRegion"] forState:UIControlStateNormal];
			customPinView.leftCalloutAccessoryView = removeRegionButton;
            
            return customPinView;

        }
        else
        {
            //NSLog(@"Inside pinView Standard Part");
            pinView.annotation = annotation;
        }
        
        return pinView;
    }
    
    return nil;
}

@end
