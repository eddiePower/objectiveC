//////////////////////////////////////////////////////////////////////////
//  AlarmListController.h                                              //
//  MyStopMonitor                                                     //
//                                                                   //
//  PROJECT DESCRIPTION AREA OF EACH TASK ACHIEVED BY THIS FILE     //
//                                                                 //
//  Created by Eddie Power on 7/05/2014.                          //
//  Copyright (c) 2014 Eddie Power.                              //
//  All rights reserved.                                        //
/////////////////////////////////////////////////////////////////

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import "AlarmCell.h"
#import "AddStopController.h"
#import "ShowStopMapViewController.h"

@interface AlarmListController : UITableViewController <AddAlarmStopDelegate, CLLocationManagerDelegate>
@property(strong, nonatomic) NSManagedObjectContext *managedObjectContext;

@property(strong, nonatomic) CLLocationManager *locManager;

@property(strong, nonatomic) Alarm *anAlarmToStore;
@property(strong, nonatomic) NSMutableArray* currentAlarms; 


- (void)addAlarmRegion:(Alarm *)anAlarm;
//-(void)updateWithEvent:(NSString *)event;


@end
