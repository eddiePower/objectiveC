//////////////////////////////////////////////////////////////////////////
//  StopAnnotation.m                                                   //
//  MyStopMonitor                                                     //
//                                                                   //
//  PROJECT DESCRIPTION AREA OF EACH TASK ACHIEVED BY THIS FILE     //
//                                                                 //
//  Created by Eddie Power on 18/05/2014.                         //
//  Copyright (c) 2014 Eddie Power.                              //
//  All rights reserved.                                        //
/////////////////////////////////////////////////////////////////

#import "StopAnnotation.h"

@implementation StopAnnotation

//Using synthesize insted of self. to show what the compiler does under the hood.
//Now old probably soon to be depreciated code
@synthesize region, coordinate, radius, title, subtitle;

//Used to init annotation with built in region for monitoring
-(id)initWithCLRegion:(CLRegion *)newRegion aCoord:(CLLocationCoordinate2D)aCoord aTitle:(NSString *)aTitle andSubtitle:(NSString *)subTitle
{
    if(self = [super init])
    {
        title = aTitle;
        subtitle = subTitle;
        region = newRegion;
		coordinate = aCoord;
		//radius = region.radius;
    }
    
    return self;
}


//Used for creating only station annotations for map display only.
-(id)initWithTitle:(NSString *)aTitle aCoord:(CLLocationCoordinate2D)aCoord andSubtitle:(NSString *)subTitle
{
    if(self = [super init])
    {
        self.coordinate = aCoord;
        self.title = aTitle;
        self.subtitle = subTitle;
    }
    
    
    return self;
}

-(void)setLat:(double)lat andLong:(double)lon
{
    CLLocationCoordinate2D location;
    location.latitude = lat;
    location.longitude = lon;
    
    self.coordinate = location;
}

/*
 This method provides a custom setter so that the model is notified when the subtitle value has changed.
 * such as when a new radius is set or a pin is moved.
 */
- (void)setRadius:(CLLocationDistance)newRadius
{
	radius = newRadius;
}

@end
