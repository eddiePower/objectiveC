//////////////////////////////////////////////////////////////////////////
//  AlarmCell.m                                                        //
//  MyStopMonitor                                                     //
//                                                                   //
//  PROJECT DESCRIPTION AREA OF EACH TASK ACHIEVED BY THIS FILE     //
//                                                                 //
//  Created by Eddie Power on 7/05/2014.                          //
//  Copyright (c) 2014 Eddie Power.                              //
//  All rights reserved.                                        //
/////////////////////////////////////////////////////////////////

#import "AlarmCell.h"

@implementation AlarmCell

@end
