//////////////////////////////////////////////////////////////////////////
//  TrainLine.m                                                        //
//  MyStopMonitor                                                     //
//                                                                   //
//  PROJECT DESCRIPTION AREA OF EACH TASK ACHIEVED BY THIS FILE     //
//                                                                 //
//  Created by Eddie Power on 12/05/2014.                         //
//  Copyright (c) 2014 Eddie Power.                              //
//  All rights reserved.                                        //
/////////////////////////////////////////////////////////////////

#import "TrainLine.h"

@implementation TrainLine

-(id)initWithStopsArray:(NSArray *)anArray andTrainLineName:(NSString *)aName
{
    if (self = [super init])
    {
        self.lineStops = anArray;
        self.lineName = aName;
    }
    
    return self;
}

@end
