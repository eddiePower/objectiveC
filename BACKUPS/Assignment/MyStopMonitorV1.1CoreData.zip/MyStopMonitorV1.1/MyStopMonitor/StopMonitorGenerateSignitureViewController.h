//
//  StopMonitorGenerateSignitureViewController.h
//  MyStopMonitor
//
//  Created by Eddie Power on 7/05/2014.
//  Copyright (c) 2014 Eddie Power. All rights reserved.
//

#import <UIKit/UIKit.h>
#include <CommonCrypto/CommonHMAC.h>

@interface StopMonitorGenerateSignitureViewController : UIViewController

@property (weak, nonatomic) NSString *signedURL;
@property (weak, nonatomic) IBOutlet UILabel *signitureLabel;

-(NSURL*) generateURLWithDevIDAndKey: (NSString*)urlPath;

@end
