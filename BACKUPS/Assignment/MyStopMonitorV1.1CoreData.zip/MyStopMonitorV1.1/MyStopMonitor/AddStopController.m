//
//  AddStopController.m
//  MyStopMonitor
//
//  Created by Eddie Power on 7/05/2014.
//  Copyright (c) 2014 Eddie Power. All rights reserved.
//

#import "AddStopController.h"

@implementation AddStopController

-(void)viewDidLoad
{
    [super viewDidLoad];
    
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] initWithEntityName:@"Station"];
    
    //Initalize trainLine object
    self.trainLine = [[TrainLine alloc] init];
    
    //create variable to store error info
    NSError *error;
    //store the trainLine Array in the managed object context
    self.trainLine.lineStops = [self.managedObjectContext executeFetchRequest: fetchRequest error:&error];
    
    //If nil is returned then an error occured in retrieving Station Data.
    if (self.trainLine.lineStops == nil)
    {
        NSLog(@"Could not Fetch Station Data:\n%@", error.userInfo);
    }
    else if ([self.trainLine.lineStops count] == 0)   //Else if there is 0 stops then run addStationData method
    {
        [self addStationData];
    }
}

/*
 This is the method that populates the station list for the train line
 this data is at the moment bieng generated on app init but will soon be
 pulled in a JSON request to fill the managedObjectContext with managedObjects
 or Stations to be more specific.
 */
-(void)addStationData
{
    //Create a new station object to be saved in the managedObjectContext area as a managedObject
    // matching JSON data and types
    Station *data = [NSEntityDescription insertNewObjectForEntityForName:@"Station" inManagedObjectContext:self.managedObjectContext];
    data.stationSuburb = @"Frankston";
    data.stationName = @"Frankston Station";
    data.stationLatitude = [NSNumber numberWithDouble: -38.143332];
    data.stationLongitude = [NSNumber numberWithDouble: 145.125942];
    data.stationStopType = @"train";
    data.stationStopId = [NSNumber numberWithInt: 1073];
    data.stationDistance = [NSNumber numberWithInt: 0];
    
    //Station 2
    data = [NSEntityDescription insertNewObjectForEntityForName:@"Station" inManagedObjectContext:self.managedObjectContext];
    data.stationSuburb = @"Kananook";
    data.stationName = @"Kananook Station";
    data.stationLatitude = [NSNumber numberWithDouble: -38.120748];
    data.stationLongitude = [NSNumber numberWithDouble: 145.135771];
    data.stationStopType = @"train";
    data.stationStopId = [NSNumber numberWithInt: 1073];
    data.stationDistance = [NSNumber numberWithInt: 0];
    
    //Station 3
    data = [NSEntityDescription insertNewObjectForEntityForName:@"Station" inManagedObjectContext:self.managedObjectContext];
    data.stationSuburb = @"Seaford";
    data.stationName = @"Seaford Station";
    data.stationLatitude = [NSNumber numberWithDouble: -38.104119];
    data.stationLongitude = [NSNumber numberWithDouble: 145.128163];
    data.stationStopType = @"train";
    data.stationStopId = [NSNumber numberWithInt: 1073];
    data.stationDistance = [NSNumber numberWithInt: 0];
    
    //Station 4
    data = [NSEntityDescription insertNewObjectForEntityForName:@"Station" inManagedObjectContext:self.managedObjectContext];
    data.stationSuburb = @"Carrum";
    data.stationName = @"Carrum Station";
    data.stationLatitude = [NSNumber numberWithDouble: -38.075575];
    data.stationLongitude = [NSNumber numberWithDouble: 145.122556];
    data.stationStopType = @"train";
    data.stationStopId = [NSNumber numberWithInt: 1073];
    data.stationDistance = [NSNumber numberWithInt: 0];
    
    //Station 5
    data = [NSEntityDescription insertNewObjectForEntityForName:@"Station" inManagedObjectContext:self.managedObjectContext];
    data.stationSuburb = @"Bonbeach";
    data.stationName = @"Bonbeach Station";
    data.stationLatitude = [NSNumber numberWithDouble: -38.062821];
    data.stationLongitude = [NSNumber numberWithDouble: 145.119766];
    data.stationStopType = @"train";
    data.stationStopId = [NSNumber numberWithInt: 1073];
    data.stationDistance = [NSNumber numberWithInt: 0];
    
    //Station 6
    data = [NSEntityDescription insertNewObjectForEntityForName:@"Station" inManagedObjectContext:self.managedObjectContext];
    data.stationSuburb = @"Chelsea";
    data.stationName = @"Chelsea Station";
    data.stationLatitude = [NSNumber numberWithDouble: -38.052220];
    data.stationLongitude = [NSNumber numberWithDouble: 145.116133];
    data.stationStopType = @"train";
    data.stationStopId = [NSNumber numberWithInt: 1073];
    data.stationDistance = [NSNumber numberWithInt: 0];
    
    NSError *error;
    
    if (![self.managedObjectContext save:&error])
    {
        NSLog(@"Could not save Train Line Stops:\n%@", error.userInfo);
    }
    else
    {
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] initWithEntityName:@"Station"];
        self.trainLine.lineStops = [self.managedObjectContext executeFetchRequest: fetchRequest error: &error];
       
        if (self.trainLine.lineStops == nil)
        {
            NSLog(@"Could not assign Saved Station for train Line:\n%@", error.userInfo);
        }
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of stops for this Train Line object in the section.
    return [self.trainLine.lineStops count];
}

//Used to display items in the tableView on Add stop Table View.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //Set the refrence to the cell Identifier and then to the cell.
    static NSString *CellIdentifier = @"StationCell";
    StationCell *cell = (StationCell*)[tableView dequeueReusableCellWithIdentifier: CellIdentifier
                                                                      forIndexPath: indexPath];
    
    // Configure the cell using the trainLine stops built from coreData or  ... JSON.
    Station *s = [self.trainLine.lineStops objectAtIndex: indexPath.row];
    
    cell.stopSuburbLabel.text = s.stationSuburb;
    cell.stopNameLabel.text = s.stationName;
    cell.stopLatLabel.text = [NSString stringWithFormat:@"%@", s.stationLatitude];
    cell.stopLongLabel.text = [NSString stringWithFormat:@"%@", s.stationLongitude];
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //Create a temp station object to hold selected station
    Station *selectedStation = [self.trainLine.lineStops objectAtIndex:indexPath.row];
    
    //create the new alarm object to add the station to.
    Alarm *newAlarm = [NSEntityDescription insertNewObjectForEntityForName:@"Alarm" inManagedObjectContext:self.managedObjectContext];
    
    //combine the two objects or relate them.
    newAlarm.station = selectedStation;
    
    //send the delegate method the new Alarm including selectedStation.
    [self.delegate addAlarmStop:newAlarm];
    //Pop a alarm onto the list.
    [self.navigationController popViewControllerAnimated: YES];
}

@end
