//
//  AlarmListController.h
//  MyStopMonitor
//
//  Created by Eddie Power on 7/05/2014.
//  Copyright (c) 2014 Eddie Power. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import "Station.h"
#import "Alarm.h"
#import "AlarmCell.h"
#import "AddStopController.h"
#import "ShowStopMapViewController.h"

@interface AlarmListController : UITableViewController <AddAlarmStopDelegate>

@property(strong, nonatomic) NSManagedObjectContext *managedObjectContext;
@property(strong, nonatomic) Alarm *anAlarmToStore;   //currentParty
@property(strong, nonatomic) NSMutableArray* currentAlarms;  //is an Mutabale for use with NSSet

@end
