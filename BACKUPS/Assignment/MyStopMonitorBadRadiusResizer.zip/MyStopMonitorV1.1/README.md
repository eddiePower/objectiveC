MyStopMonitor-UniAssignment
====================

Refrences :
===========

TDNotificationPanel - Green Bar In Application Banner.
    - https://github.com/tomdiggle/TDNotificationPanel 
    - Tom Diggle
    A custom class that provides a in application type notification which can consist of 3 colours and 3 different uses such as error, success and loading types.  I chose to use this to help alert the user of an upcoming train station by using the succsess color scheme.
    
ACPReminder - App in background Notification Banner.
    - https://github.com/antoniocasero/ACPReminder
    - Anton Iocasero
    A custom class that provides notifications based on the localNotification class that can be fired in a matter of seconds rather then days, i used this to help alert the user when the application is closed. To keep with the train theme i set a sound of train crossing.
===============================================================================================

This is my main assignment for Monash FIT3027 in 2014.
It is a Public transport system alert application to help those people like me who fall asleep on the train, bus or tram and miss the stop they are ment to get off at. This will send you an alert before you arrive at the station.  How is this different to the normal iphone notification at location you ask, well this is built around the PTV or public transport network victoria data so the train or stop locations are already in the app you just need to search or look through the list to select your desired stoping location.

