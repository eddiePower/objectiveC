/*////////////////////////////////////////////////////////////////////////////////
//  SettingsViewTableViewController.m                                          //
//  MyStopMonitor                                                             //
//                                                                           //
//  This project is to use the ios core location to monitor a users         //
//  location while on public transport in this case a train running        //
//  on the Frankston Line and a user will set the stop they would         //
//  like to be notified before they reach, the phone will then           //
//  alert the user to the upcoming stop and they can wake up or         //
//  prepare to disembark the train with lots of time and not           //////////
//  missing there stop. This will be widened to accept multiple               //
//  train lines and transport types in an upcoming update soon.              //
//                                                                          //
//  The above copyright notice and this permission notice shall            //
//  be included in all copies or substantial portions of the              //
//  Software.                                                            //
//                                                                      //
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY          //
//  KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE        //
//  WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR          //
//  PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE              //
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,          //
//  DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF           //
//  CONTRACT, TORT OR OTHERWISE, ARISING FROM,OUT OF OR IN       //
//  CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER            //
//  DEALINGS IN THE SOFTWARE.                                  //
//                                                            //
//  Created by Eddie Power on 7/05/2014.                     //
//  Copyright (c) 2014 Eddie Power.                         //
//  All rights reserved.                                   //
////////////////////////////////////////////////////////////*/

#import "SettingsViewController.h"
#import "YHAnimatedCircleView.h"

@interface SettingsViewController ()

@property(nonatomic)double radiusUpdate;

@end

@implementation SettingsViewController






- (MKOverlayView *)mapView:(MKMapView *)mapView viewForOverlay:(id<MKOverlay>)overlay
{
    
    YHAnimatedCircleView* circleView = [[YHAnimatedCircleView alloc] initWithCircle:(MKCircle *)overlay];
    
    return circleView;
}

-(void)addCircle:(CLLocationCoordinate2D)aCoord andRadius:(float)aRadius
{
    
    CLLocationCoordinate2D location = aCoord;
    
    //add annotation
    MKPointAnnotation *anno = [[MKPointAnnotation alloc] init];
    anno.coordinate = location;
    [self.radiusMapView addAnnotation:anno];
    
    
    
    //add overlay
    [self.radiusMapView addOverlay:[MKCircle circleWithCenterCoordinate:location radius:aRadius]];
    
    //zoom into the location with the defined circle at the middle
    [self zoomInto:location distance:(aRadius * 4.0) animated:YES];
}


#pragma mark - Helper

- (void)zoomInto:(CLLocationCoordinate2D)zoomLocation distance:(CGFloat)distance animated:(BOOL)animated{
    
    MKCoordinateRegion viewRegion = MKCoordinateRegionMakeWithDistance(zoomLocation, distance, distance);
    MKCoordinateRegion adjustedRegion = [self.radiusMapView regionThatFits:viewRegion];
    [self.radiusMapView setRegion:adjustedRegion animated:animated];
}










- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // Create userDefaults store
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
   
    NSString *tempString = [defaults objectForKey:@"alertRadius"];
    
    double startRadius = tempString.doubleValue;
    
    NSLog(@"Radius to be set on slider is: %f", startRadius / 600);
    
    self.radiusSlider.minimumValue = 0.6f;
    self.radiusSlider.maximumValue = 1.5f;
    
    self.radiusSlider.value = startRadius / 600;
    
    //Set mapView delegate
    self.radiusMapView.delegate = self;
    
    //Set the region/area for the mapView location to show. - Flinders Street Station Melbourne Australia.
    MKCoordinateRegion mapRegion;
    
    //center location for mapView
    CLLocationCoordinate2D demoRadiusCenter;
    demoRadiusCenter.latitude = -37.818078;
    demoRadiusCenter.longitude = 144.96681;
    
    //Span @ % of degree = 100th of degree
    MKCoordinateSpan demoRadiusSpan;
    demoRadiusSpan.latitudeDelta = 0.02f;
    demoRadiusSpan.longitudeDelta = 0.02f;
    
    //Set center and span for the mapView region
    mapRegion.center = demoRadiusCenter;
    mapRegion.span = demoRadiusSpan;
    
    //Set the Region to the mapView.
    [self.radiusMapView setRegion: mapRegion animated: YES];
    
    //initalize annotation for radius demo
    MKPointAnnotation *radiusDemoAnnotation = [[MKPointAnnotation alloc]init];
    
    radiusDemoAnnotation.coordinate = demoRadiusCenter;
    radiusDemoAnnotation.title = @"Flinders Street Station";
    radiusDemoAnnotation.subtitle = @"Alert radius size visualization, set for new Alerts only.";
    
    //Add annotation array to the map
    [self.radiusMapView addAnnotation: radiusDemoAnnotation];
    
    //overridden method below, adds custom pin and callout.
    [self.radiusMapView viewForAnnotation: radiusDemoAnnotation];
    
    tempString = [defaults objectForKey:@"alertRadius"];
    float tempRadius = tempString.floatValue;
    
    [self addCircle: demoRadiusCenter andRadius: tempRadius];

}

//Set the map type for demo map will also make this set main map using
//user defaults plist
- (IBAction)segmentSelected:(UISegmentedControl *)sender
{
    //NSLog(@"Segment has changed!!");
    
    switch (self.mapSegment.selectedSegmentIndex)
    {
        case 0:
            self.radiusMapView.mapType = MKMapTypeStandard;
            break;
        case 1:
            self.radiusMapView.mapType = MKMapTypeHybrid;
            break;
        case 2:
            self.radiusMapView.mapType = MKMapTypeSatellite;
            break;
        default:
            break;
    }
}

- (IBAction)sliderValueChanged:(id)sender
{
    // Create userDefaults store
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    
    UISlider *tempSlider = sender;
    
    [defaults setDouble: tempSlider.value * 600 forKey:@"alertRadius"];
    [defaults synchronize];
    
    //[self configureOverlay];
    MKCircle *tempOverlay = [self.radiusMapView.overlays firstObject];
    [self.radiusMapView removeOverlay:[self.radiusMapView.overlays firstObject]];

    //Convert the string to double
    NSString *tempString = [defaults objectForKey:@"alertRadius"];
    //Number space for label output.
    NSNumber *radiusNumber = [NSNumber numberWithDouble: tempString.doubleValue];
    //Format the number data type for radius to appear in a clean decimal 0.000 format.
    NSNumberFormatter *formatter = [[NSNumberFormatter alloc] init];
    //this rounds the decimal places off to 3.
    formatter.numberStyle = NSNumberFormatterDecimalStyle;
    //store a string of the formatted number item_price.
    NSString *radiusFormatted = [formatter stringFromNumber: radiusNumber];
    
    self.radiusSizeLabel.text = [NSString stringWithFormat:@"Size: %@ meters", radiusFormatted];
    
    
    [self addCircle: tempOverlay.coordinate andRadius: tempString.floatValue];

}

@end
