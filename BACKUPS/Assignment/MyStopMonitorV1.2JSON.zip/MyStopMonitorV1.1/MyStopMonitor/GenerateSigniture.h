//
//  GenerateSigniture.h
//  MyStopMonitorV1.1
//
//  Created by Eddie Power on 28/05/2014.
//  Copyright (c) 2014 Eddie Power. All rights reserved.
//

#import <Foundation/Foundation.h>
#include <CommonCrypto/CommonHMAC.h>

@interface GenerateSigniture : NSObject

-(NSURL*) generateURLWithDevIDAndKey: (NSString*)urlPath;

@end
