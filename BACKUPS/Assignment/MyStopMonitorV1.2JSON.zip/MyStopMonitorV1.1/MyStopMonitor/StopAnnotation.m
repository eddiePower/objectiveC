//
//  StopAnnotation.m
//  MyStopMonitor
//
//  Created by Eddie Power on 18/05/2014.
//  Copyright (c) 2014 Eddie Power. All rights reserved.
//

#import "StopAnnotation.h"

@implementation StopAnnotation

- (CLLocationCoordinate2D)coordinate
{
    coordinate.latitude = [self.latitude doubleValue];
    coordinate.longitude = [self.longitude doubleValue];
    return coordinate;
}

// required if you set the MKPinAnnotationView's "canShowCallout" property to YES
- (NSString *)title
{
    return self.Name;
}

// optional
- (NSString *)subtitle
{
    return self.Subtitle;
}

@end
