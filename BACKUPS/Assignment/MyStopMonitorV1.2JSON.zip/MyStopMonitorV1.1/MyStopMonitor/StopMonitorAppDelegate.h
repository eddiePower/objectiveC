//////////////////////////////////////////////////////////////////////////
//  StopMonitorAppDelegate.h                                           //
//  MyStopMonitor                                                     //
//                                                                   //
//  PROJECT DESCRIPTION AREA OF EACH TASK ACHIEVED BY THIS FILE     //
//                                                                 //
//  Created by Eddie Power on 23/04/2014                          //
//  Copyright (c) 2014 Eddie Power.                              //
//  All rights reserved.                                        //
/////////////////////////////////////////////////////////////////

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import "AlarmListController.h"

@interface StopMonitorAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) NSManagedObjectModel *managedObjectModel;
@property (strong, nonatomic) NSPersistentStoreCoordinator *persistentStoreCoordinator;
@property (strong, nonatomic) NSManagedObjectContext *managedObjectContext;

@end
