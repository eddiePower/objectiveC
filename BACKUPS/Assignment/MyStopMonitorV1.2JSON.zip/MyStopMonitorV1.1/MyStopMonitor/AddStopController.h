//
//  AddStopController.h
//  MyStopMonitor
//
//  Created by Eddie Power on 7/05/2014.
//  Copyright (c) 2014 Eddie Power. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import "Station.h"
#import "Alarm.h"
#import "StationCell.h"
#import "TrainLine.h"
#import "GenerateSigniture.h"

@protocol AddAlarmStopDelegate <NSObject>

-(void)addAlarmStop:(Alarm *)anAlarm;

@end

@interface AddStopController : UITableViewController

@property(strong, nonatomic) NSArray *array;
@property(strong, nonatomic) NSManagedObjectContext *managedObjectContext;
@property(weak, nonatomic) id<AddAlarmStopDelegate> delegate;

//Will update application to work with multiple train lines and eventually bus and tram lines.
//@property (strong, nonatomic) TrainLine* trainLine;

@end
