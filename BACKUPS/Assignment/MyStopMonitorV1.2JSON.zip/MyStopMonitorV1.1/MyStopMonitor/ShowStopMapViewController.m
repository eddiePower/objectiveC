//////////////////////////////////////////////////////////////////////////
//  ShowStopMapViewController.h                                        //
//  MyStopMonitor                                                     //
//                                                                   //
//  PROJECT DESCRIPTION AREA OF EACH TASK ACHIEVED BY THIS FILE     //
//                                                                 //
//  Created by Eddie Power on 1/05/2014.                          //
//  Copyright (c) 2014 Eddie Power.                              //
//  All rights reserved.                                        //
/////////////////////////////////////////////////////////////////


#import "ShowStopMapViewController.h"
#import "StopAnnotation.h"

@interface ShowStopMapViewController ()

@property (nonatomic, strong) NSMutableArray *mapAnnotations;


@end

@implementation ShowStopMapViewController

+ (CGFloat)annotationPadding;
{
    return 10.0f;
}

+ (CGFloat)calloutHeight;
{
    return 40.0f;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.mapView.showsBuildings = YES;
    self.mapView.showsUserLocation = YES;
    
    //set location for map to center on from the station object selected.
    //To create a Coordinate object we need 2 LocationDegrees
    // for lat and long.
    CLLocationDegrees latitude = [self.mapStation.stationLatitude doubleValue];
    CLLocationDegrees longitude = [self.mapStation.stationLongitude doubleValue];
    self.mapCoordinate = CLLocationCoordinate2DMake(latitude, longitude);
   
    //Set the region/area for the mapView location to show.
    MKCoordinateRegion mapRegion;
    //Set center for the map region
    mapRegion.center = self.mapCoordinate;
    //Set the zoom amount small is close large is far.
    mapRegion.span.latitudeDelta = 0.01;
    mapRegion.span.longitudeDelta = 0.01;
    //Set the Region to the mapView.
    [self.mapView setRegion: mapRegion animated: YES];
    
    //MARKER FOR THE STATION'S
    
    // create out annotations array (in this example only 2)
    self.mapAnnotations = [[NSMutableArray alloc] initWithCapacity: 1];
    
    // annotation for Stop
    StopAnnotation *item = [[StopAnnotation alloc] init];
    
    item.Name = self.mapStation.stationName;
    item.Subtitle = self.mapStation.stationStopType;
    item.latitude = @([self.mapStation.stationLatitude doubleValue]);
    item.longitude = @([self.mapStation.stationLongitude doubleValue]);
    
    //NSLog(@"The item Identifier is: %@", item.class);
    
    //Not actually calling overridden method below, just running normal and returning nil.
    //[self.mapView viewForAnnotation: item];
    
    //Add annotation to array
    [self.mapAnnotations insertObject: item atIndex: 0];
    
    // remove any annotations that exist
    //[self.mapView removeAnnotations: self.mapView.annotations];
    
    //Add annotation array to the map
    [self.mapView addAnnotations: self.mapAnnotations];
    
    //FUTURE ADD TO MARKER THE MYKI OUTLET STATUS AND PARKING STATUS OF STATIONS.
    //Maybe in the call outs or annotations.
}

#pragma mark - MKMapViewDelegate

//Not Used atm.
- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(StopAnnotation *)annotation
{
    
    NSLog(@"EDDIE DEBUG LINE 1");
    
    // in case it's the user location, we already have an annotation, so just return nil
    if ([annotation isKindOfClass:[MKUserLocation class]])
    {
        return nil;
    }

    // handle my custom annotation may add others for bus/train/tram or other use.
    // for station or stop annotation
    if ([annotation isKindOfClass:[StopAnnotation class]])
    {
        // try to dequeue an existing pin view first
        static NSString *StopAnnotationIdentifier = @"StopAnnotation";
        
        NSLog(@"EDDIE DEBUG LINE 2");
        
        MKPinAnnotationView *pinView =
        (MKPinAnnotationView *) [self.mapView dequeueReusableAnnotationViewWithIdentifier: StopAnnotationIdentifier];
        if (pinView == nil)
        {
            //if an existing pin view was not available, create one
            MKPinAnnotationView *customPinView =
            [[MKPinAnnotationView alloc] initWithAnnotation: annotation reuseIdentifier: StopAnnotationIdentifier];
            
            //Customize the pin view.
            customPinView.pinColor = MKPinAnnotationColorPurple;
            customPinView.animatesDrop = YES;
            customPinView.canShowCallout = YES;
            
            //Add a custom icon for the station/stop call out box
            UIImageView *stopIconView = [[UIImageView alloc] initWithImage:[UIImage imageNamed: @"StopIcon.png"]];
            customPinView.rightCalloutAccessoryView = stopIconView;
            
            NSLog(@"Inside CustomPinView Part");
            
            return customPinView;
        }
        else
        {
            NSLog(@"Inside pinView Standard Part");
            pinView.annotation = annotation;
        }
        NSLog(@"EDDIE DEBUG LINE Before returning pinView object!!");
        
        return pinView;
    }
    NSLog(@"EDDIE DEBUG LINE End of viewforAnnotation method before returning nill :(");
    
    return nil;
}
@end
