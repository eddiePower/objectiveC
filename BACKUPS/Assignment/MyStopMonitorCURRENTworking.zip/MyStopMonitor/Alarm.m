//
//  Alarm.m
//  MyStopMonitorV1.1
//
//  Created by Eddie Power on 11/06/2014.
//  Copyright (c) 2014 Eddie Power. All rights reserved.
//

#import "Alarm.h"
#import "Station.h"


@implementation Alarm

@dynamic alarmAlertRadius;
@dynamic alarmIsActive;
@dynamic alarmTime;
@dynamic alarmTitle;
@dynamic station;

@end
