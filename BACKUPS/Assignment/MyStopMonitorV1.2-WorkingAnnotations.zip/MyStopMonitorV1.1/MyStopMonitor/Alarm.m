//////////////////////////////////////////////////////////////////////////
//  Alarm.m                                                            //
//  MyStopMonitor                                                     //
//                                                                   //
//  PROJECT DESCRIPTION AREA OF EACH TASK ACHIEVED BY THIS FILE     //
//                                                                 //
//  Created by Eddie Power on 28/05/2014.                         //
//  Copyright (c) 2014 Eddie Power.                              //
//  All rights reserved.                                        //
/////////////////////////////////////////////////////////////////


#import "Alarm.h"
#import "Station.h"


@implementation Alarm

@dynamic alarmAlertRadius;
@dynamic alarmIsActive;
@dynamic alarmTime;
@dynamic station;

@end
