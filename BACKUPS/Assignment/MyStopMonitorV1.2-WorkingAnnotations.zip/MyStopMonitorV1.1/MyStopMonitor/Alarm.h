//////////////////////////////////////////////////////////////////////////
//  Alarm.h                                                            //
//  MyStopMonitor                                                     //
//                                                                   //
//  PROJECT DESCRIPTION AREA OF EACH TASK ACHIEVED BY THIS FILE     //
//                                                                 //
//  Created by Eddie Power on 28/05/2014.                         //
//  Copyright (c) 2014 Eddie Power.                              //
//  All rights reserved.                                        //
/////////////////////////////////////////////////////////////////


#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Station;

@interface Alarm : NSManagedObject

@property (nonatomic, retain) NSNumber * alarmAlertRadius;
@property (nonatomic, retain) NSNumber * alarmIsActive;
@property (nonatomic, retain) NSDate * alarmTime;
@property (nonatomic, retain) Station *station;

@end
