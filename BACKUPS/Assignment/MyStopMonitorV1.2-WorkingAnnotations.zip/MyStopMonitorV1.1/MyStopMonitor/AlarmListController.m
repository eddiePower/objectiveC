//////////////////////////////////////////////////////////////////////////
//  AlarmListController.m                                              //
//  MyStopMonitor                                                     //
//                                                                   //
//  PROJECT DESCRIPTION AREA OF EACH TASK ACHIEVED BY THIS FILE     //
//                                                                 //
//  Created by Eddie Power on 7/05/2014.                          //
//  Copyright (c) 2014 Eddie Power.                              //
//  All rights reserved.                                        //
/////////////////////////////////////////////////////////////////

#import "AlarmListController.h"

@implementation AlarmListController

-(void)viewDidLoad
{
    [super viewDidLoad];
    
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] initWithEntityName:@"Alarm"];
    
    NSError *error;
    NSArray *results = [self.managedObjectContext executeFetchRequest:fetchRequest error:&error];
    
    if(results == nil)
    {
        NSLog(@"Could Not fetch Alarm:\n%@", error.userInfo);
    }
    else if ([results count] == 0)
    {
        self.currentAlarms = [[NSMutableArray alloc] initWithCapacity: 0];
    }
    else
    {
        //Use mutableCopy of Array results as current alarms is a mutable array.
        self.currentAlarms = [results mutableCopy];
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    //One for alarms and other for count of alarms.
    // This may change to save screen realestate.
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    switch (section)
    {
        case 0:
            //count rows in section
            return [self.currentAlarms count];
            break;
        case 1:
            //or its just 1 row for total
            return 1;
    }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0)
    {
       static NSString *CellIdentifier = @"AlarmCell";
       AlarmCell *cell = (AlarmCell*)[tableView dequeueReusableCellWithIdentifier: CellIdentifier
                                                                     forIndexPath: indexPath];

       // Configure the Alarm cell with some alarm details.
       Alarm* a = [self.currentAlarms objectAtIndex: indexPath.row];
    
        cell.alarmSuburbLabel.text = a.station.stationSuburb;
        cell.alarmStopNameLabel.text = a.station.stationName;
        cell.alarmLocationLabel.text = [NSString stringWithFormat:@"%@,\n%@", a.station.stationLatitude, a.station.stationLongitude];
    
       return cell;
    }
    else
    {
        //Total Alarms count cell.
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"TotalCell"
                                                                forIndexPath: indexPath];
        cell.textLabel.text = [NSString stringWithFormat:@"Total Alarms Set: %lu", (unsigned long)[self.currentAlarms count]];
        
        return cell;
    }
    
    return nil;
}

//Table View method to stop editing / deleting of a specific row in this case the alarm count.
-(BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    //If the section is the first one or section 0 then allow editing
    if(indexPath.section == 0)
        return YES;
    
    //Otherwise its the alarm count section and no editing permitted.
    return NO;
}

//Save or delete a row and update table view data and display.
-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    //If they type of edit initiated by the user is the delete action then
    if (editingStyle == UITableViewCellEditingStyleDelete)
    {
        //Create a temp alarm object to store alarm to remove in
        Alarm *alarmToRemove = [self.currentAlarms objectAtIndex: indexPath.row];
        
        //remove the alarm object from the currentAlarms
        [self.currentAlarms removeObject:alarmToRemove];
        
        //Update the alarms array with the mutableCopy of
        self.currentAlarms = [self.currentAlarms mutableCopy];
        
        //remove the same alarmObject from the managedObjectContext space
        // so that the core data will reflect the Table View Alarm list.
        [self.managedObjectContext deleteObject:alarmToRemove];
        
        //Set the animation of the delete action
        //Comment out to switch to reload all table data
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation: UITableViewRowAnimationFade];
        
        //set animation of the reloaded rows moving up in place of removed row.
        //combines delete and reload tableView data in one.
        [self.tableView reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow: 0 inSection: 1]] withRowAnimation:UITableViewRowAnimationNone];

        //Error checking on the managedObjectContext save method.
        NSError *error;
        if (![self.managedObjectContext save: &error])
        {
            NSLog(@"Could not delete Alarm:\n%@", error.userInfo);
        }
    }
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.identifier isEqualToString:@"AddAlarmSegue"])
    {
        AddStopController* controller = segue.destinationViewController;
        controller.managedObjectContext = self.managedObjectContext;
        controller.delegate = self;
    }
    else if ([segue.identifier isEqualToString:@"showMapSegue"])
    {
        //set the controller to the segue destination from storyboard
        ShowStopMapViewController* controller = segue.destinationViewController;
        
        //May need delegate later to return data from mapView
        //controller.delegate = self;
        
        //select the index path sent over by sender or cell selected
        NSIndexPath* indexPath = [self.tableView indexPathForCell: sender];
        
        //create the alarm for the data sent from the indexPath and row for exact data
        Alarm* selectedAlarm = [self.currentAlarms objectAtIndex:indexPath.row];

        //now send [selectedAlarm's Station name from above or self] to the destination
        //view and a variable called mapStation in destination view which is of type
        //Station for my purposes of getting station data
        controller.mapStation = selectedAlarm.station;
    }
}



-(void)addAlarmStop:(Alarm *)anAlarm
{
    //set other alarm properties which user can edit later.
    anAlarm.alarmIsActive = [NSNumber numberWithInt: 1]; //link to switch to set alarm active/inactive
    anAlarm.alarmAlertRadius = [NSNumber numberWithFloat: 33.23];  //link to slider to adjust radius of region
    anAlarm.alarmTime = [NSDate date];  //date of creation may be used after future update to set repeating alarms.

    //Add alarm to the array for viewing in the Table View.
    [self.currentAlarms addObject:anAlarm];
    
    //Reload TableView Data to show new alarm.
    [self.tableView reloadData];
   
    //Set error space to debug any errors
    NSError *error;
    
    //if an error occured when saving to managedObject then show userInfo formated output.
    if(![self.managedObjectContext save: &error])
    {
        NSLog(@"Could not add Station to the alarm:\n%@", error.userInfo);
    }
}

@end
