//////////////////////////////////////////////////////////////////////////
//  AddStopController.m                                                //
//  MyStopMonitor                                                     //
//                                                                   //
//  PROJECT DESCRIPTION AREA OF EACH TASK ACHIEVED BY THIS FILE     //
//                                                                 //
//  Created by Eddie Power on 7/05/2014.                          //
//  Copyright (c) 2014 Eddie Power.                              //
//  All rights reserved.                                        //
/////////////////////////////////////////////////////////////////

#import "AddStopController.h"

@implementation AddStopController

-(void)viewDidLoad
{
    [super viewDidLoad];
    
    //Create a fetchRequest to check count of objects not to actually run.
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] initWithEntityName:@"Station"];
    
    //Set a temp error storage space for count request.
    NSError *error;
    //store integer from a count items returned from managedObjectContext.
    NSUInteger count = [self.managedObjectContext countForFetchRequest: fetchRequest
                                                                 error: &error];
    
    //NSLog(@"Count in ManagedObjectContext space is %lu", (unsigned long)count);
    
    //Check the ManagedObjectContext Objects count if its 0
    // then download new copy of stations otherwise use the ones
    //saved in core Data. unless there is an error then go back to
    if (count == 0)
    {
        [self downloadStationData];
    }
    else if(count == NSNotFound)
    {
        NSLog(@"Error Retrieving Stations or downloads trainLine from PTV: %@", error.userInfo);
        return;
    }
    else
    {
        [self fetchStationData];
    }
    
}

-(void)downloadStationData
{
    NSURL *url;
    
    GenerateSigniture *getSigniture = [[GenerateSigniture alloc] init];
    
    url = [getSigniture generateURLWithDevIDAndKey:@"http://timetableapi.ptv.vic.gov.au/v2/mode/0/line/6/stops-for-line"];

    NSURLRequest* request = [NSURLRequest requestWithURL: url];
    
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *error)
    {
      if(error == nil)
      {
          [self parseStationJSON: data];
          [self fetchStationData];
      }
      else
      {
        NSLog(@"Connection Error:\n%@", error.userInfo);
      }
    }];
    
}

-(void)fetchStationData
{
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] initWithEntityName:@"Station"];
    NSSortDescriptor *nameSort = [NSSortDescriptor sortDescriptorWithKey:@"stationName" ascending:YES];
    
    [fetchRequest setSortDescriptors:@[nameSort]];
    
    
    
    NSError *error;
    
      self.array = [[NSArray alloc] init];
      self.array = [self.managedObjectContext executeFetchRequest: fetchRequest error:&error];
    
    if (self.array == nil)
    {
        NSLog(@"Could not Fetch Station Data:\n%@", error.userInfo);
    }
    
}

-(void)parseStationJSON:(NSData *)data
{
    NSError *error;
    id result = [NSJSONSerialization JSONObjectWithData: data options: NSJSONReadingMutableContainers error:&error];
    
    if (result == nil)
    {
        NSLog(@"Error parsing JSON data:\n%@", error.userInfo);
        return;
    }
    
    
    if([result isKindOfClass:[NSArray class]])
    {
        NSArray *StationArray = (NSArray *)result;
        NSLog(@"Found %lu Stations!", (unsigned long)[StationArray count]);
        
        for (NSDictionary* station in StationArray)
        {
            Station *aStation = [NSEntityDescription insertNewObjectForEntityForName:@"Station" inManagedObjectContext:self.managedObjectContext];
            
            aStation.stationName = [station objectForKey:@"location_name"];
            aStation.stationSuburb = [station objectForKey:@"suburb"];
            aStation.stationStopId = [station objectForKey:@"stop_id"];
            aStation.stationStopType = [station objectForKey:@"transport_type"];
            aStation.stationLatitude = [station objectForKey:@"lat"];
            aStation.stationLongitude = [station objectForKey:@"lon"];
            aStation.stationDistance = [station objectForKey:@"distance"];
        }
        
        self.array = StationArray;
        
        NSLog(@"Number of stops in Array is now: %lu", (long unsigned)[self.array count]);
        
        
        NSError *error;
        
        if (![self.managedObjectContext save:&error])
        {
            NSLog(@"Could not save Train Line Stops:\n%@", error.userInfo);
        }
        
    }
    else
    {
        NSLog(@"Unexpected JSON format");
        return;
    }
    
    [self.tableView reloadData];
    
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of stops for this Train Line object in the section.
    return [self.array count];
}

//Used to display items in the tableView on Add stop Table View.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //Set the refrence to the cell Identifier and then to the cell.
    static NSString *CellIdentifier = @"StationCell";
    
    StationCell *cell = (StationCell*)[tableView dequeueReusableCellWithIdentifier: CellIdentifier
                                                                      forIndexPath: indexPath];
    
    // Configure the cell using the trainLine stops built from coreData or  ... JSON.
    Station *s = [self.array objectAtIndex: indexPath.row];
    
    cell.stopSuburbLabel.text = s.stationSuburb;
    cell.stopNameLabel.text = s.stationName;
    cell.stopLatLabel.text = [NSString stringWithFormat:@"%@", s.stationLatitude];
    cell.stopLongLabel.text = [NSString stringWithFormat:@"%@", s.stationLongitude];
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //Create a temp station object to hold selected station
    Station *selectedStation = [self.array objectAtIndex:indexPath.row];
    
    //create the new alarm object to add the station to.
    Alarm *newAlarm = [NSEntityDescription insertNewObjectForEntityForName:@"Alarm" inManagedObjectContext:self.managedObjectContext];
    
    //combine the two objects or relate them.
    newAlarm.station = selectedStation;
    
    //send the delegate method the new Alarm including selectedStation.
    [self.delegate addAlarmStop:newAlarm];
    //Pop a alarm onto the list.
    [self.navigationController popViewControllerAnimated: YES];
}

@end
