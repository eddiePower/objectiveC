///////////////////////////////////////////////////////////////////////////
//  ShowStopMapViewController.h                                         //
//  MyStopMonitor                                                      //
//                                                                    //
//  This view controller draws the map details for the alarm         //
//  in the users main alarm list                                    //
//                                                                 //
//  Created by Eddie Power on 30/04/2014.                         //
//  Copyright (c) 2014 Eddie Power.                              //
//  All rights reserved.                                        //
/////////////////////////////////////////////////////////////////

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import "Station.h"
#import "StopAnnotation.h"

@interface ShowStopMapViewController : UIViewController <MKMapViewDelegate>

@property (strong, nonatomic) IBOutlet MKMapView *mapView;

@property (nonatomic, readonly) MKMapRect boundingMapRect;
@property (nonatomic) CLLocationCoordinate2D mapCoordinate;
@property (strong, nonatomic) Station* mapStation;

@end
