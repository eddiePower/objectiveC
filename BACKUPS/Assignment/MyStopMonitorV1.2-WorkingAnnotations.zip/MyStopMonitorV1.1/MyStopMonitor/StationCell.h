//////////////////////////////////////////////////////////////////////////
//  StationCell.h                                                      //
//  MyStopMonitor                                                     //
//                                                                   //
//  PROJECT DESCRIPTION AREA OF EACH TASK ACHIEVED BY THIS FILE     //
//                                                                 //
//  Created by Eddie Power on 7/05/2014.                          //
//  Copyright (c) 2014 Eddie Power.                              //
//  All rights reserved.                                        //
/////////////////////////////////////////////////////////////////

#import <UIKit/UIKit.h>

@interface StationCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *stopSuburbLabel;
@property (weak, nonatomic) IBOutlet UILabel *stopNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *stopLatLabel;
@property (weak, nonatomic) IBOutlet UILabel *stopLongLabel;

@end
