//////////////////////////////////////////////////////////////////////////
//  StopAnnotation.h                                                   //
//  MyStopMonitor                                                     //
//                                                                   //
//  PROJECT DESCRIPTION AREA OF EACH TASK ACHIEVED BY THIS FILE     //
//                                                                 //
//  Created by Eddie Power on 18/05/2014.                         //
//  Copyright (c) 2014 Eddie Power.                              //
//  All rights reserved.                                        //
/////////////////////////////////////////////////////////////////

#import <MapKit/MapKit.h>

@interface StopAnnotation : NSObject <MKAnnotation>

@property (nonatomic) CLLocationCoordinate2D coordinate;
@property (nonatomic, copy) NSString* title;
@property (nonatomic, copy) NSString* subtitle;

-(id)initWithTitle:(NSString *)title andSubtitle:(NSString *)subTitle;
-(void)setLat:(double)lat andLong:(double)lon;

@end
