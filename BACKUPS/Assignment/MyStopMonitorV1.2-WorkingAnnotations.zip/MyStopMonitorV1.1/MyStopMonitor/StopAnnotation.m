//////////////////////////////////////////////////////////////////////////
//  StopAnnotation.m                                                   //
//  MyStopMonitor                                                     //
//                                                                   //
//  PROJECT DESCRIPTION AREA OF EACH TASK ACHIEVED BY THIS FILE     //
//                                                                 //
//  Created by Eddie Power on 18/05/2014.                         //
//  Copyright (c) 2014 Eddie Power.                              //
//  All rights reserved.                                        //
/////////////////////////////////////////////////////////////////

#import "StopAnnotation.h"

@implementation StopAnnotation

-(id)initWithTitle:(NSString *)title andSubtitle:(NSString *)subTitle
{
    if(self = [super init])
    {
        self.title = title;
        self.subtitle = subTitle;
    }
    
    return self;
}

-(void)setLat:(double)lat andLong:(double)lon
{
    CLLocationCoordinate2D location;
    location.latitude = lat;
    location.longitude = lon;
    
    self.coordinate = location;
}

@end
