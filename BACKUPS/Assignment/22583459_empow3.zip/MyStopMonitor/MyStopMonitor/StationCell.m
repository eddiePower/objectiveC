//  StationCell.m                                                             
//  MyStopMonitor

//  This class is used to layout a prototype Table View Cell
//  that displays a Station's details, this is a subclass of the
//  UITableViewCell class.

//  Created by Eddie Power on 7/05/2014.
//  Copyright (c) 2014 Eddie Power.
//  All rights reserved.

#import "StationCell.h"

@implementation StationCell

@end
