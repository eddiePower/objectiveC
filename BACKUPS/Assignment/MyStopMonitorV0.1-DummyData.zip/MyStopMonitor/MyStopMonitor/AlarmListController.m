//
//  AlarmListController.m
//  MyStopMonitor
//
//  Created by Eddie Power on 7/05/2014.
//  Copyright (c) 2014 Eddie Power. All rights reserved.
//

#import "AlarmListController.h"

@interface AlarmListController ()

@end

@implementation AlarmListController

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    
    if (self)
    {
        //Create an empty mutable array
        self.currentAlarms = [[NSMutableArray alloc] init];
    }
    return self;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    switch (section)
    {
        case 0:
            return [self.currentAlarms count];
            break;
        case 1:
            return 1;
    }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0)
    {
       static NSString *CellIdentifier = @"AlarmCell";
       AlarmCell *cell = (AlarmCell*)[tableView dequeueReusableCellWithIdentifier: CellIdentifier
                                                                     forIndexPath: indexPath];
        
        //NSLog(@"Saving object to Row number: %ld", indexPath.row + 1);

        
       // Configure the cell...
       Station* a = [self.currentAlarms objectAtIndex: indexPath.row];
    
       cell.alarmSuburbLabel.text = a.stopSuburb;
       cell.alarmStopNameLabel.text = a.stopName;
       cell.alarmLocationLabel.text = [NSString stringWithFormat:@"%f, %f", a.stopLatitude, a.stopLongitude];
    
       return cell;
    }
    else
    {
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"TotalCell"
                                                                forIndexPath: indexPath];
        cell.textLabel.text = [NSString stringWithFormat:@"Total Alarms Set: %lu", (unsigned long)[self.currentAlarms count]];
        
        return cell;
    }
    
    return nil;
}

-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete)
    {
        [self.currentAlarms removeObjectAtIndex: indexPath.row];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
        [self.tableView reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow: 0 inSection: 1]] withRowAnimation:UITableViewRowAnimationNone];
    }
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.identifier isEqualToString:@"AddAlarmSegue"])
    {
        AddStopController* controller = segue.destinationViewController;
        controller.delegate = self;
    }
}


-(void)addStop:(Station*)aStation
{
    [self.currentAlarms addObject:aStation];
    [self.tableView reloadData];
}

@end
