//
//  AddStopController.h
//  MyStopMonitor
//
//  Created by Eddie Power on 7/05/2014.
//  Copyright (c) 2014 Eddie Power. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Station.h"
#import "StationCell.h"

@protocol AddStopDelegate <NSObject>

-(void)addStop:(Station*)aStation;

@end

@interface AddStopController : UITableViewController

@property (strong, nonatomic) NSArray* allStops;
@property (weak, nonatomic) id<AddStopDelegate> delegate;

@end
