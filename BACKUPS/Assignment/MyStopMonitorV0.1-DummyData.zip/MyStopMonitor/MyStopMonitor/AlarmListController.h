//
//  AlarmListController.h
//  MyStopMonitor
//
//  Created by Eddie Power on 7/05/2014.
//  Copyright (c) 2014 Eddie Power. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Station.h"
#import "Alarm.h"
#import "AlarmCell.h"
#import "AddStopController.h"

@interface AlarmListController : UITableViewController <AddStopDelegate>

@property(strong, nonatomic) NSMutableArray* currentAlarms;

@end
