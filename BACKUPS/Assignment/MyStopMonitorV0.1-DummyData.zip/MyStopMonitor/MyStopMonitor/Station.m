//
//  Station.m
//  MyStopMonitor
//
//  Created by Eddie Power on 7/05/2014.
//  Copyright (c) 2014 Eddie Power. All rights reserved.
//

#import "Station.h"

@implementation Station


- (id)initWithSuburb:(NSString*)aStopSuburb stopName:(NSString*)aStopName stopLatitude:(double)aStopLatitude andStopLongitude:(double)aStopLongitude
{
    if (self = [super init])
    {
        self.stopSuburb = aStopSuburb;
        self.stopName = aStopName;
        self.stopLatitude = aStopLatitude;
        self.stopLongitude = aStopLongitude;
    }
    
    return self;
}


@end
