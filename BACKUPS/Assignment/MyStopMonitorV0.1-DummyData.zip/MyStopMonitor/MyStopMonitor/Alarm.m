//
//  Alarm.m
//  MyStopMonitor
//
//  Created by Eddie Power on 7/05/2014.
//  Copyright (c) 2014 Eddie Power. All rights reserved.
//

#import "Alarm.h"

@implementation Alarm

- (id)initWithName:(NSString*)aSuburb stopName:(NSString*)aStopName andLocation:(NSString*)aLocation
{
    if (self = [super init])
    {
        self.suburb = aSuburb;
        self.stopName = aStopName;
        self.stopLocation = aLocation;
    }
    
    return self;
}

@end
