//
//  Alarm.h
//  MyStopMonitor
//
//  Created by Eddie Power on 7/05/2014.
//  Copyright (c) 2014 Eddie Power. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Alarm : NSObject

@property (strong, nonatomic) NSString* suburb;
@property (strong, nonatomic) NSString* stopName;
@property (strong, nonatomic) NSString* stopLocation;

- (id)initWithName:(NSString*)aSuburb stopName:(NSString*)aStopName andLocation:(NSString*)aLocation;

@end
