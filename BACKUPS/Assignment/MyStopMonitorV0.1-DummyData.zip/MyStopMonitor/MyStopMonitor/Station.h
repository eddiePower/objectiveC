//
//  Station.h
//  MyStopMonitor
//
//  Created by Eddie Power on 7/05/2014.
//  Copyright (c) 2014 Eddie Power. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Station : NSObject

@property (strong, nonatomic) NSString* stopSuburb;
@property (strong, nonatomic) NSString* stopName;
@property (nonatomic) double stopLatitude;
@property (nonatomic) double stopLongitude;

- (id)initWithSuburb:(NSString*)aStopSuburb stopName:(NSString*)aStopName stopLatitude:(double)aStopLatitude andStopLongitude:(double)aStopLongitude;

@end
