//
//  main.m
//  ACPReminderExample
//
//  Created by Antonio Casero on 4/27/14
//  Copyright (c) 2014 Uttopia. All rights reserved.
//

@import UIKit;

#import "ACPAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ACPAppDelegate class]));
    }
}
