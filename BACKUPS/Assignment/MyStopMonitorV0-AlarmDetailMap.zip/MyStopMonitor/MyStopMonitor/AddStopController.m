//
//  AddStopController.m
//  MyStopMonitor
//
//  Created by Eddie Power on 7/05/2014.
//  Copyright (c) 2014 Eddie Power. All rights reserved.
//

#import "AddStopController.h"

@interface AddStopController ()

@end

@implementation AddStopController

- (id)initWithCoder:(NSCoder *)aDecoder
{
    if (self = [super initWithCoder:aDecoder])
    {
        Station* s1 = [[Station alloc] initWithSuburb:@"Frankston" stopName:@"Frankston Station" stopType:@"Train" stopLatitude: -38.143429 stopLongitude: 145.125932 andStopId: 6];
        Station* s2 = [[Station alloc] initWithSuburb:@"Kananook" stopName:@"Kananook Station" stopType:@"Train" stopLatitude: -38.120746 stopLongitude: 145.135771 andStopId: 7];
        Station* s3 = [[Station alloc] initWithSuburb: @"Seaford" stopName: @"Seaford Station" stopType:@"Train" stopLatitude: -38.104119 stopLongitude: 145.128163 andStopId: 8];
        Station* s4 = [[Station alloc] initWithSuburb:@"Carrum" stopName:@"Carrum Station" stopType:@"Train" stopLatitude: -38.075575 stopLongitude: 145.122556 andStopId: 9];
        Station* s5 = [[Station alloc] initWithSuburb:@"Bonbeach" stopName:@"Bonbeach Station" stopType:@"Train" stopLatitude: -38.062821 stopLongitude: 145.119766 andStopId: 10];
        Station* s6 = [[Station alloc] initWithSuburb:@"Chelsea" stopName:@"Chelsea Station" stopType:@"Train" stopLatitude: -38.052220 stopLongitude: 145.116133 andStopId: 10];
        
        //self.allStops = [NSArray arrayWithObjects:s1, s2, s3, s4, s5, s6, nil];
        self.trainLine = [[TrainLine alloc] initWithStopsArray: [NSArray arrayWithObjects:s1, s2, s3, s4, s5, s6, nil] andTrainLineName:@"Frankston Line"];
    }
    
    return self;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of stops for this Train Line object in the section.
    return [self.trainLine.lineStops count];
}

//Used to display items in the tableView on Add stop Table View.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //Set the refrence to the cell Identifier and then to the cell.
    static NSString *CellIdentifier = @"StationCell";
    StationCell *cell = (StationCell*)[tableView dequeueReusableCellWithIdentifier: CellIdentifier
                                                                      forIndexPath: indexPath];
    
    // Configure the cell...
    Station* s = [self.trainLine.lineStops objectAtIndex: indexPath.row];
    
    cell.stopSuburbLabel.text = s.stopSuburb;
    cell.stopNameLabel.text = s.stopName;
    cell.stopLatLabel.text = [NSString stringWithFormat:@"%f", s.stopLatitude];
    cell.stopLongLabel.text = [NSString stringWithFormat:@"%f", s.stopLongitude];
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    Alarm * selectedStation = [[Alarm alloc] init];
    selectedStation.alarmStation = [self.trainLine.lineStops objectAtIndex:indexPath.row];
    //Send more alarm related data to alarm list here (alarm time.
    
    //NSLog(@"Row number Selected is: %ld", indexPath.row + 1);
    [self.delegate addStop: selectedStation];
    [self.navigationController popViewControllerAnimated: YES];
}

@end
