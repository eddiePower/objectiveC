//
//  TrainLine.h
//  MyStopMonitor
//
//  Created by Eddie Power on 12/05/2014.
//  Copyright (c) 2014 Eddie Power. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Station.h"

@interface TrainLine : NSObject

//An array of station objects making up the train line.
@property (strong, nonatomic) NSArray* lineStops;
//The train Line name for user display etc.
@property (strong, nonatomic) NSString* lineName;

-(id)initWithStopsArray:(NSArray *)anArray andTrainLineName:(NSString *)aName;

@end
