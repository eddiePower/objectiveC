//
//  Station.m
//  MyStopMonitor
//
//  Created by Eddie Power on 7/05/2014.
//  Copyright (c) 2014 Eddie Power. All rights reserved.
//

#import "Station.h"

@implementation Station


- (id)initWithSuburb:(NSString*)aStopSuburb stopName:(NSString*)aStopName stopType:(NSString*)aStopType
        stopLatitude:(double)aStopLatitude stopLongitude:(double)aStopLongitude andStopId:(int)aStopId
{
    if (self = [super init])
    {
        self.stopSuburb = aStopSuburb;
        self.stopName = aStopName;
        self.stopType = aStopType;
        self.stopLatitude = aStopLatitude;
        self.stopLongitude = aStopLongitude;
        self.stopId = aStopId;
    }
    
    return self;
}


@end
