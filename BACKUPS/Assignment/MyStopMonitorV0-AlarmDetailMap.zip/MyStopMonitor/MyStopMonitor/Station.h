//
//  Station.h
//  MyStopMonitor
//
//  Created by Eddie Power on 7/05/2014.
//  Copyright (c) 2014 Eddie Power. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Station : NSObject

@property (strong, nonatomic) NSString* stopSuburb;
@property (strong, nonatomic) NSString* stopName;
@property (strong, nonatomic) NSString* stopType;
@property (nonatomic) double stopLatitude;
@property (nonatomic) double stopLongitude;
@property (nonatomic) int stopId;

//-----TO-ADD-LATER!!----------------------
//@property (nonatomic) BOOL* stopHasParking;
//@property (strong, nonatomic) BOOL stopHasMykiOutlet;

- (id)initWithSuburb:(NSString*)aStopSuburb stopName:(NSString*)aStopName stopType:(NSString*)aStopType
        stopLatitude:(double)aStopLatitude stopLongitude:(double)aStopLongitude andStopId:(int)aStopId;

@end
