//////////////////////////////////////////////////////////////////////////
//  StopMonitorAppDelegate.h                                           //
//  MyStopMonitor                                                     //
//                                                                   //
//  PROJECT DESCRIPTION AREA OF EACH TASK ACHIEVED BY THIS FILE     //
//                                                                 //
//  Created by Eddie Power on 23/04/2014                          //
//  Copyright (c) 2014 Eddie Power.                              //
//  All rights reserved.                                        //
/////////////////////////////////////////////////////////////////

#import <UIKit/UIKit.h>

@interface StopMonitorAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
