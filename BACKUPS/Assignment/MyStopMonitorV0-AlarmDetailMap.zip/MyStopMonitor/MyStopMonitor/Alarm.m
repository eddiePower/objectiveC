//
//  Alarm.m
//  MyStopMonitor
//
//  Created by Eddie Power on 7/05/2014.
//  Copyright (c) 2014 Eddie Power. All rights reserved.
//

#import "Alarm.h"

@implementation Alarm

- (id)initWithAlarmStation:(Station*)aAlarmStation alarmTime:(NSDate*)aAlarmTime
             alarmIsActive:(BOOL)aAlarmIsActive andAlertDistance:(int)aAlertDistance
{
    if (self = [super init])
    {
        //Station object will include location, suburb name, stop name etc.
        self.alarmStation = aAlarmStation;
        self.alarmTime = aAlarmTime;
        self.alarmIsActive = aAlarmIsActive;
        self.alarmAlertDistance = aAlertDistance;
    }
    
    return self;
}

@end
