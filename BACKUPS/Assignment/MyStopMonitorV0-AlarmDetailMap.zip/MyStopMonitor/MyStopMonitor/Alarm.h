//
//  Alarm.h
//  MyStopMonitor
//
//  Created by Eddie Power on 7/05/2014.
//  Copyright (c) 2014 Eddie Power. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Station.h"

@interface Alarm : NSObject

@property (strong, nonatomic) Station* alarmStation;
@property (strong, nonatomic) NSDate* alarmTime;
@property (nonatomic) BOOL alarmIsActive;
@property (nonatomic) int alarmAlertDistance;

- (id)initWithAlarmStation:(Station*)aAlarmStation alarmTime:(NSDate*)aAlarmTime
             alarmIsActive:(BOOL)aAlarmIsActive andAlertDistance:(int)aAlertDistance;

@end
