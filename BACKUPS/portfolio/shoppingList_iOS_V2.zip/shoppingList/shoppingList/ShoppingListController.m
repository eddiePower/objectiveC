//
//  ShoppingListController.m
//  shoppingList
//
//  Created by Eddie Power on 2/04/2014.
//  Copyright (c) 2014 Eddie Power. All rights reserved.
//

#import "ShoppingListController.h"

@implementation ShoppingListController

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self)
    {
        self.currentShoppingList = [[shoppingList alloc] init];
    }
    return self;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    switch(section)
    {
        case 0:
            return [self.currentShoppingList.myShoppingList count];
        case 1:
            return 1;
    }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section == 0)
    {
        ItemCell *cell = (ItemCell*)[tableView dequeueReusableCellWithIdentifier:@"ItemCell" forIndexPath:indexPath];
        // Configure the Item cell with text and price...
        item* i = [self.currentShoppingList.myShoppingList objectAtIndex:indexPath.row];
        cell.nameLabel.text = i.name;
        cell.priceLabel.text = [NSString stringWithFormat:@"Price: $%.2f", i.price];
        
        if([i.name isEqualToString:@"Red Bull"])
        {
            cell.nameLabel.textColor = [UIColor blueColor];
        }
        else if([i.name isEqualToString:@"Green Apple"])
        {
            cell.nameLabel.textColor = [UIColor greenColor];
        }
        else if([i.name isEqualToString:@"TV Snacks"])
        {
            cell.nameLabel.textColor = [UIColor brownColor];
        }
        else if([i.name isEqualToString:@"Bulla Ice Cream"])
        {
            cell.nameLabel.textColor = [UIColor grayColor];
        }
        
        return cell;
    }
    else
    {
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"TotalPriceCell"forIndexPath:indexPath];
        cell.textLabel.text = [NSString stringWithFormat:@"List Total: $%.2f",[self.currentShoppingList calcTotalCost: self.currentShoppingList.myShoppingList]];
        return cell;
    }
    return nil;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section == 0)
        return YES;
    return NO;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete)
    {
        [self.currentShoppingList.myShoppingList removeObjectAtIndex:indexPath.row];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
        [self.tableView reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:0 inSection:1]] withRowAnimation:UITableViewRowAnimationNone];
    }
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if([segue.identifier isEqualToString:@"AddItemSegue"])
    {
        AddItemController* controller = segue.destinationViewController;
        controller.delegate = self;
    }
}

-(void)addItem:(item *)item
{
    [self.currentShoppingList.myShoppingList addObject:item];
    [self.tableView reloadData];
}

@end
