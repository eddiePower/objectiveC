//
//  AddItemController.m
//  shoppingList
//
//  Created by Eddie Power on 2/04/2014.
//  Copyright (c) 2014 Eddie Power. All rights reserved.
//

#import "AddItemController.h"

@implementation AddItemController

- (id)initWithCoder:(NSCoder *)aDecoder
{
    if(self = [super initWithCoder:aDecoder])
    {
        item* i1 = [[item alloc] initWithName:@"Red Bull" itemDescription:@"Energy in a can people." itemPrice: 5.95];
        item* i2 = [[item alloc] initWithName:@"Green Apple" itemDescription:@"2 week old fresh fruit" itemPrice: 0.95];
        item* i3 = [[item alloc] initWithName:@"TV Snacks" itemDescription:@"Choclate Buiscutes" itemPrice: 6.95];
        item* i4 = [[item alloc] initWithName:@"Whole Chicken" itemDescription:@"One of the left over bird flew birds." itemPrice: 15.95];
        item* i5 = [[item alloc] initWithName:@"Bulla Ice Cream" itemDescription:@"Full Cream Vanilla Ice Cream 2L" itemPrice: 7.00];
        
        self.allItems = [NSArray arrayWithObjects:i1, i2, i3, i4, i5, nil];
    }
    return self;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.allItems count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"ItemCell";
    ItemCell *cell = (ItemCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    
    // Configure the cell...
    item* i = [self.allItems objectAtIndex:indexPath.row];
    cell.nameLabel.text = i.name;
    cell.priceLabel.text = [NSString stringWithFormat:@"Price: $%.2f", i.price];
    
    if([i.name isEqualToString:@"Red Bull"])
    {
        cell.nameLabel.textColor = [UIColor blueColor];
    }
    else if([i.name isEqualToString:@"Green Apple"])
    {
        cell.nameLabel.textColor = [UIColor greenColor];
    }
    else if([i.name isEqualToString:@"TV Snacks"])
    {
        cell.nameLabel.textColor = [UIColor brownColor];
    }
    else if([i.name isEqualToString:@"Bulla Ice Cream"])
    {
        cell.nameLabel.textColor = [UIColor grayColor];
    }
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    item* selectedItem = [self.allItems objectAtIndex:indexPath.row];
    [self.delegate addItem:selectedItem];
    [self.navigationController popViewControllerAnimated:YES];
}

@end
