//
//  ItemData.m
//  shoppingList
//
//  Created by Eddie Power on 16/04/2014.
//  Copyright (c) 2014 Eddie Power. All rights reserved.
//

#import "ItemData.h"


@implementation ItemData

@dynamic item_name;
@dynamic item_description;
@dynamic item_price;

@end
