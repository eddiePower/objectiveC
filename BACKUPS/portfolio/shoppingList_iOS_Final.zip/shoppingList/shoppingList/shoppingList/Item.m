//
//  Item.m
//  shoppingList
//
//  Created by Eddie Power on 16/04/2014.
//  Copyright (c) 2014 Eddie Power. All rights reserved.
//

#import "Item.h"


@implementation Item

//dynamic because they now come from either the plist or coreData i think.
@dynamic item_name;
@dynamic item_description;
@dynamic item_price;
@dynamic shoppingList;

@end
